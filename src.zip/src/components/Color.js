// colors.js
const colors = {
    inputBorderColor: '#000000', 
    // black
    // Add other colors as needed
  };
  
  export default colors;
  